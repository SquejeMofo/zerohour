# respite
A WIP NutScript Schema
This schema has been being worked on for a long time, that being the case it has a lot of older and deprecated plugins. The file structure will also be a bit disorganized.
This is mainly being uploaded so that other Nutscript developers can use what they want from it, or learn from some of the stuff it does to do whatever. 
You should not attempt to run a server the same as mine, and instead change the schema's name and run it with a different storyline.

Do not expect me to fix too many minor bugs, especially in plugins that I did not create. This will be updated infrequently, usually only after I implement a decent amount of content.