PLUGIN.name = "Junk Items"
PLUGIN.author = "Chancer"
PLUGIN.desc = "A pile of junk items."

