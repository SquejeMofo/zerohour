ITEM.name = "Framed Picture(3)"
ITEM.uniqueID = "j_picture_3"
ITEM.model = "models/props_c17/Frame002a.mdl"
ITEM.desc = "A wooden picture frame."
ITEM.flag = "j"
ITEM.width = 2
ITEM.height = 3
ITEM.skin = 3

ITEM.data = { scrapamount = 2 }
ITEM.salvItem = "j_scrap_wood"

ITEM.iconCam = {
	pos = Vector(200, 0, 0),
	ang = Angle(180, -0, 180),
	fov = 10.5,
}