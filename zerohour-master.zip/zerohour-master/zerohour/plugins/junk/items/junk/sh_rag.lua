ITEM.name = "Rag"
ITEM.uniqueID = "j_old_rag"
ITEM.model = "models/props_debris/metal_panelshard01c.mdl"
ITEM.desc = "An old rag."
ITEM.flag = "j"
ITEM.width = 1
ITEM.height = 1
ITEM.material = "models/props_c17/furnituremetal001a"
	
ITEM.data = { scrapamount = 1 }
ITEM.salvItem = "j_scrap_cloth"

ITEM.iconCam = {
	pos = Vector(236.01995849609, 201.69137573242, 134.17846679688),
	ang = Angle(25, 220, 0),
	fov = 4.8720669895869,
}