--this is a joke item, you should probably delete it
ITEM.name = "Gay Porn Magazine"
ITEM.uniqueID = "j_porn_gay"
ITEM.model = "models/props_c17/paper01.mdl"
ITEM.desc = "An old magazine filled with gay men doing gay things."
ITEM.flag = "j"
ITEM.width = 1
ITEM.height = 1

ITEM.data = { scrapamount = 3 }
ITEM.salvItem = "j_scrap_adhesive"

ITEM.iconCam = {
	pos = Vector(0, -3.5, 200),
	ang = Angle(90, 0, 0),
	fov = 7,
}