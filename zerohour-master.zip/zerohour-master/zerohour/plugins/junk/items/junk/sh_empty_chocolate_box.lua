ITEM.name = "Empty Confection Box"
ITEM.uniqueID = "j_empty_chocolate_box"
ITEM.model = "models/props_lab/box01b.mdl"
ITEM.desc = "An empty box that smells pretty good."
ITEM.flag = "j"
ITEM.width = 1
ITEM.height = 1

ITEM.data = { scrapamount = 1 }
ITEM.salvItem = "j_scrap_cloth"

ITEM.iconCam = {
	pos = Vector(89.432174682617, 74.904991149902, 54.501823425293),
	ang = Angle(25, 220, 0),
	fov = 5,
}