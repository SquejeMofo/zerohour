ITEM.name = "Tea Leaf"
ITEM.uniqueID = "j_tealeaf"
ITEM.model = "models/props/cs_office/plant01_gib2.mdl"
ITEM.desc = "A tea leaf."
ITEM.flag = "j"
ITEM.width = 1
ITEM.height = 1

ITEM.data = { scrapamount = 1 }
ITEM.salvItem = "j_scrap_organic"

ITEM.iconCam = {
	pos = Vector(54.184516906738, 45.64688873291, 33.115924835205),
	ang = Angle(25, 220, 0),
	fov = 4.2087710507229,
}