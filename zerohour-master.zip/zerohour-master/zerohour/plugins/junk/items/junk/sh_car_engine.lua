ITEM.name = "Car Engine"
ITEM.uniqueID = "j_car_engine"
ITEM.model = "models/props_c17/TrapPropeller_Engine.mdl"
ITEM.desc = "An engine block from some sort of vehicle."
ITEM.flag = "j"
ITEM.width = 5
ITEM.height = 4

ITEM.data = { scrapamount = 6 }

ITEM.salvItem = {
	["j_scrap_metals"] = 6,
	["j_scrap_chems"] = 2
}