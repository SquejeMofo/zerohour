ITEM.name = "Toothbrushes"
ITEM.uniqueID = "j_tbrushes"
ITEM.model = "models/props/cs_militia/toothbrushset01.mdl"
ITEM.desc = "A small set of toothbrushes."
ITEM.flag = "j"
ITEM.width = 1
ITEM.height = 1

ITEM.data = { scrapamount = 1 }
ITEM.salvItem = "j_scrap_plastics"
