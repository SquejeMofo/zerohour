ITEM.name = "Old Shoe"
ITEM.uniqueID = "j_old_shoe"
ITEM.model = "models/props_junk/Shoe001a.mdl"
ITEM.desc = "An old worn shoe."
ITEM.flag = "j"
ITEM.width = 1
ITEM.height = 1

ITEM.data = { scrapamount = 2 }
ITEM.salvItem = "j_scrap_cloth"

ITEM.iconCam = {
	pos = Vector(0, 200, 0),
	ang = Angle(0, 270, 0),
	fov = 4.5,
}