# Notes Plugin
Author: Black Tea za rebel1324


---
<p>First version of Notes Plugin, ported from NS 1.0.</p>