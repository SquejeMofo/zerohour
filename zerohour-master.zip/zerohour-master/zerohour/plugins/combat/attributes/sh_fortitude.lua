ATTRIBUTE.name = "Fortitude"
ATTRIBUTE.desc = "Your character's mental fortitude and strength."