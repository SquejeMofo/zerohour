ATTRIBUTE.name = "Craftiness"
ATTRIBUTE.desc = "Your character's skill with construction, crafting, and general ingenuity."