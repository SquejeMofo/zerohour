ATTRIBUTE.name = "Perception"
ATTRIBUTE.desc = "Your character's skills in detecting and observation."