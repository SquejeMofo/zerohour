ITEM.name = "Various Chemicals"
ITEM.uniqueID = "j_scrap_chems"
ITEM.model = "models/props_junk/garbage_plasticbottle002a.mdl"
ITEM.desc = "Some various chemicals."
ITEM.flag = "j"
ITEM.width = 1
ITEM.height = 1
ITEM.maxstack = 50

ITEM.data = {
	Amount = 1
}

ITEM.iconCam = {
	pos = Vector(-200, 0, 0),
	ang = Angle(0, -0, 0),
	fov = 6.5,
}