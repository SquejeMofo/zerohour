ITEM.name = "Scrap Wood"
ITEM.uniqueID = "j_scrap_wood"
ITEM.model = "models/gibs/wood_gib01a.mdl"
ITEM.desc = "Some scrap wood."
ITEM.flag = "j"
ITEM.width = 1
ITEM.height = 1
ITEM.maxstack = 35

ITEM.data = {
	Amount = 1
}

ITEM.iconCam = {
	pos = Vector(0, 0, 200),
	ang = Angle(90, 0, 0),
	fov = 18,
}