ITEM.name = "Cloth"
ITEM.uniqueID = "j_scrap_cloth"
ITEM.model = "models/props_lab/box01a.mdl"
ITEM.material = "models/props_c17/furniturefabric003a"
ITEM.desc = "Some cloth."
ITEM.flag = "j"
ITEM.width = 1
ITEM.height = 1

ITEM.data = {
	Amount = 1
}

ITEM.iconCam = {
	pos = Vector(89.432174682617, 74.904991149902, 54.501823425293),
	ang = Angle(25, 220, 0),
	fov = 5,
}