ITEM.name = "Some Plastic"
ITEM.uniqueID = "j_scrap_plastics"
ITEM.model = "models/props_wasteland/prison_toiletchunk01a.mdl"
ITEM.desc = "A small chunk of some kind of plastic."
ITEM.flag = "j"
ITEM.width = 1
ITEM.height = 1

ITEM.data = {
	Amount = 1
}

ITEM.iconCam = {
	pos = Vector(-200, -2, -9),
	ang = Angle(0, -0, 0),
	fov = 4.75,
}