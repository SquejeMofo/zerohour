LANGUAGE = {
	lc_youGathered = "You gathered %s",
	lc_gatherSpawn = "You've added a new gathering spawner",
  lc_noSpace = "You have no space left in your inventory!",
	lc_noEntity = "You haven't specified an entity to spawn!",
	lc_noTable = "You haven't specified a table for the gathering entity!",
	lc_noTableName = "There is no table inside this entity called like that!",
	lc_removedSpawners = "%d spawners have been removed",
	lc_display = "Displaying all gathering spawnpoints for 15 seconds"
}
