ITEM.name = "Darkness"
ITEM.desc = "A story of a man and his realizations"
ITEM.price = 0
ITEM.flag = "3"

ITEM.iconCam = {
	pos = Vector(0, 200, 6),
	ang = Angle(0, 270, 0),
	fov = 4.5,
}

ITEM.contents = [[
		<p align="center"><font color='red' size='6'>DARKNESS</font></p><br/>
		<font color='black' size='3'>
		Brian 'Joker' Doughty says "Holy fucking shit."<br/><br/>


		Brian 'Joker' Doughty says "People."<br/><br/>


		Brian 'Joker' Doughty says "Then again, you guys probably are the ones who just stand around and act like they're alive."<br/><br/>


		Brian 'Joker' Doughty says "When really you're just robots holding weapons and planning on the human's untimely death."<br/><br/>


		Brian 'Joker' Doughty says "I bet one of you are about to turn around and shoot me right now for unfolding your plans."<br/><br/>


		**Brian 'Joker' Doughty glances around. "Anyone? Huh?"<br/><br/>


		**One of the guards just nods to the other. They both turn to look at Brian.<br/><br/>


		Brian 'Joker' Doughty says "I fucking knew it."<br/><br/>


		**They both look back at each other and nod once again.<br/><br/>


		Brian 'Joker' Doughty says "You two have been planning since day one."<br/><br/>


		Brian 'Joker' Doughty says "Since this whole thing started."<br/><br/>


		Brian 'Joker' Doughty says "It's a conspiracy."<br/><br/>


		**One of the guards begins making clicking noises to the other.<br/><br/>


		Brian 'Joker' Doughty says "Anyone out there really isn't dead. Us humans are hallucinating."<br/><br/>


		Brian 'Joker' Doughty says "You've drugged us to think they're flesh-eating parasitic zom-zoms."<br/><br/>


		**The guards are just clicking back and forth now.<br/><br/>


		Brian 'Joker' Doughty says "And they're the ones truly suffering."<br/><br/>


		**They're still clicking.<br/><br/>


		Brian 'Joker' Doughty says "They come to us for help, and we see them attacking."<br/><br/>


		**Suddenly, people.<br/><br/>


		**Brian 'Joker' Doughty glances around.<br/><br/>


		Brian 'Joker' Doughty says "WHO ARE YOU PEOPLE."<br/><br/>


		**Brian 'Joker' Doughty raises his hands up to his chest, glancing down at them,<br/><br/>


		Brian 'Joker' Doughty says "This whole fucking life has been a lie."<br/><br/>


		Brian 'Joker' Doughty says "I am not a nineteen-year-old American jackass."<br/><br/>


		**The one black man closest to Brian just stares at him.<br/><br/>


		**Lovingly.<br/><br/>


		Brian 'Joker' Doughty says "I am not living in the middle of an apocalypse- well, actually, yes I am."<br/><br/>


		**Brian 'Joker' Doughty glances up at he man. "STOP IT."<br/><br/>


		**The man winks.<br/><br/>


		Brian 'Joker' Doughty says "What I truly am is-"<br/><br/>


		**Brian 'Joker' Doughty gasps, soon falling onto his knees as he pulls out his copy of Metro 2033. "I AM REALLY ARTYOM."<br/><br/>


		Brian 'Joker' Doughty says "THIS BOOK IS JUST A RECOLLECTION OF MY LIFE IN THE PAST EIGHT DAYS."<br/><br/>


		**The black man makes a clicking noise and nods, "Metro for the pure race."<br/><br/>


		Brian 'Joker' Doughty says "THE DARK ONES DID ACTUALLY STOP ME FROM LAUNCHING THE NUKES AND NOW I'M IN THEIR VERSION OF PURGATORIAL HELL."<br/><br/>


		Brian 'Joker' Doughty yells "MILLER! KHAN! ULHMAN? ANYBODY?"<br/><br/>


		**One of the guards just furrows his brow as he watches Brian in amusement. The black man just seems terrified of him now.<br/><br/>


		Brian 'Joker' Doughty yells "I NEED HELP! PLEASE, DON'T LEAVE ME TO DIE LIKE THIS!"<br/><br/>


		**Brian 'Joker' Doughty soon jumps up to his feet, glancing around in a panicked way. "No. NO! YOU'RE ALL NOT REAL! YOU'REALLNOTREAL!" He soon bolts off, screaming.<br/><br/>


		**Brian 'Joker' Doughty slams into a wall, grunting heavily as he falls backwards onto the floor, unconscious.<br/><br/>


		**What with this kind of commotion, it wouldn't be hard to believe that a guard would come up to check Brian, scan him and then sit him up against a wall or something.<br/><br/>


		**Which they do. The guard that does arrive also slaps Brian in the face and leaves quickly.

		
		</font>

		]]