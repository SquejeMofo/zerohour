ITEM.name = "The Ill of Will"
ITEM.desc = "A small journal with a black cover, it has a odd circular symbol atop of it."
ITEM.uniqueID = "story_sun_shade1"
ITEM.price = 0
ITEM.flag = "3"

ITEM.iconCam = {
	pos = Vector(0, 200, 6),
	ang = Angle(0, 270, 0),
	fov = 4.5,
}

ITEM.contents = [[
	<p align="center"><font color='black' size='6'>The Book Of Spite</font></p><br/>
	<p align="center"><font color='black' size='4'>The Ill of Will.</font></p><br/>
		<font color='black' size='3'>
		Spite is.. A troublesome emotion. It's angry, its harsh. It's hateful and barren, devoid of happiness and love. It's.. Inhuman in a way. It's challenging because its so.. Horribly inept for being a true human - It causes depression, rips away at your soul and just.. Devours all that you love. What human being could really live with themselves having such a horrible emotion?
		I couldn't.
	<br/><br/>
		Maliciously intented, Spite was the emotion I just couldn't rid myself of conventionally. I tried, I tried incredibly so to remove that piece of me. But- I never expected this to happen. 
		When I became what I am now, I knew that all these alterations of my being had to be written down somewhere, I couldn't just leave this unspoken. I could never really tell anyone, so I guess these books are going to be more like personal journals than anything else.
	<br/><br/>
		The ill of will, maliciousness incarnated in that of a singular being. Spite is the culmination of bitterness and hostility, the negative emotion that solely defines a singular being. Whether intentionally or unintetnionally, Spite disturbs the peace heavily with their inability to accept any positive emotions expressed by those around. Thus is tries its hardest to delve into the darkest parts of Drifters, ripping apart their previous lives in both incredibly devious ways, and incredibly destructive manners. 
	<br/><br/>
		The ironic part? I felt spiteful... Just because I had that emotion within me. 
	<br/><br/>
		So I removed it.
	<br/><br/>
		I removed him.
	<br/><br/>
		Yet.. They're only one part of it all... Only one part of me.

		</font>
]]