ITEM.name = "The F. Word"
ITEM.desc = "A book about dealing with children appropriately."
ITEM.flag = "k"

ITEM.iconCam = {
	pos = Vector(0, 200, 6),
	ang = Angle(0, 270, 0),
	fov = 4.5,
}

ITEM.contents = [[
<h1>The F. Word</h1>
<h3>By A Good Parent</h3>
<p>
<font size = '+2'>M</font>ommy!' my son cried out as he ran into the room, 'Cherish just said
the f-word!' I set my book down, took his hand and asked, 'What is the f-word?'

He looked around the room. 'It's okay to tell me, honey.'
Meeting my gaze, he shrugged, 'It's 'Fuck!'

I squeezed his hand and called to his sister's bedroom, 'Cherish,
come in here. Right now.'

AND THEN I MOTHERFUCKING KIDNEY PUNCHED THAT BITCH, YOU DONT FUCKING USE THAT GOD DAMN LANGUAGE IN MY HOUSE YOU LITTLE SHIT BAG
I RUINED MY VAGINA FOR YOU.
</p>
]]