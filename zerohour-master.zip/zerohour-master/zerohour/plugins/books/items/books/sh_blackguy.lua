ITEM.name = "The Black Guy"
ITEM.desc = "A black colored book with the black guy on it."
ITEM.flag = "k"

ITEM.iconCam = {
	pos = Vector(0, 200, 6),
	ang = Angle(0, 270, 0),
	fov = 4.5,
}

ITEM.contents = [[
<h1>The Black Guy</h1>
<h3>By Abraham Lincoln</h3>
<p>
He was just like everyone else, you racist.
</p>
]]