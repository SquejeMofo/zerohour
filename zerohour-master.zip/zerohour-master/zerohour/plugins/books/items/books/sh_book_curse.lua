ITEM.name = "The Curse"
ITEM.desc = "A book about a curse."
ITEM.price = 0
ITEM.flag = "3"

ITEM.iconCam = {
	pos = Vector(0, 200, 6),
	ang = Angle(0, 270, 0),
	fov = 4.5,
}

ITEM.contents = [[
		<p align="center"><font color='red' size='6'>The Curse</font></p><br/>
		<font color='black' size='3'>Do you believe in Fate? The gods of Fortune? Do you know that little bitch that calls itself Karma?
Superstitions are everywhere. Have you not avoided crossing the path of a black cat? Haven’t we all made a wish when your eye suddenly catches the clock when it strikes 11:11? For some professional sports players they won’t even shave during the playoffs, because for them a clean shave means you are preordained to lose the game before it even starts.
<br/><br/>
We all do something to change our luck for the better, or avoid it getting worse. It’s human nature to be superstitious, to touch wood after saying something in hopes it never happens. But what do you do when it feels like nothing works? Everything you try to spark a change makes no goddamn difference? What if you’re simply… cursed.
		</font>

		]]