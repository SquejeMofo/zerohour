ITEM.name = "Hamburger"
ITEM.uniqueID = "food_hamburger"
ITEM.model = "models/food/burger.mdl"
ITEM.hungerAmount = 30
ITEM.foodDesc = "A tasty looking hamburger."
ITEM.quantity = 2
ITEM.price = 4
ITEM.width = 1
ITEM.height = 1
ITEM.mustCooked = true
--5 str

ITEM.attribBoosts = { ["str"] = 6, ["end"] = 8}