PLUGIN.name = "Stat Equipment"
PLUGIN.author = "Chancer"
PLUGIN.desc = "Equipment items that give stat bonuses."